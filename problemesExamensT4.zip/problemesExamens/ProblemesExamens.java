package problemesExamens;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;
/**
 * Classe ProblemesExamens: problemes d'exàmens del Tema 4 de cursos anteriors.
 *
 * @author PRG
 * @version Curs 2019/20
 */
public class ProblemesExamens {
    private ProblemesExamens() { }
    
    /** P2 - Curs 18/19 */
    public static void sumInt(String fileIn, String fileOut) throws FileNotFoundException {
        /* COMPLETAR */
    }
    
    /** RecP2 - Curs 18/19 */
    public static void filtraErrors(String fileIn, String fileOut) throws FileNotFoundException {
        /* COMPLETAR */
    }
    
    /** P2 - Curs 17/18 */
    public static File fromArrayToTextFile(int[] a) {
        File res = new File("ArrayElements.txt");
        /* COMPLETAR */
        return res;
    }
    
    /** P2 - Curs 16/17 */
    public static void fitxerNou(String ftx) {
        /* COMPLETAR */
    }
    
    /** RecP2 - Curs 16/17 */
    public static int lligISuma(String nomFitxer) {
        int suma = 0;
        /* COMPLETAR */
        return suma;
    }
}